# Skill Candidates

Proposals submitted by implementing agents via `REDUNDANCY REPORT → project-manager` blocks.
The PM agent owns this file. Update status as proposals are evaluated.

## Status Values

| Status | Meaning |
|--------|---------|
| `proposed` | Just received — not yet evaluated |
| `watching` | Recurrence not confirmed; re-evaluate after 2+ more occurrences |
| `approved` | Meets all criteria; scheduled for skill creation |
| `created` | Skill file now exists in `.claude/skills/` |
| `declined` | Does not meet criteria or already covered by existing skill |

---

## Log

| Date | Suggested Skill | Reported By | Session | Times Seen | Status | Notes |
|------|----------------|-------------|---------|-----------|--------|-------|
| — | — | — | — | — | — | No reports yet |

---

## Existing Skills (for deduplication check)

Before adding a new row, confirm the pattern is NOT already covered:

| Skill | Trigger |
|-------|---------|
| `create-endpoint` | Creating any new FastAPI route |
| `create-component` | Creating any new React component, hook, or store action |
| `db-migration` | Adding/modifying DB tables, columns, or indexes |
| `add-to-backlog` | Tracking a new item mid-session |
| `review` | Post-implementation code review |
| `check-tests` | Post-review test assessment |
| `new-session` | Session start ritual |
| `end-session` | Session close ritual |
